package com.example.danilodionisia.combustvel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editPrecoAlcool;
    private EditText editPrecoGasolina;
    private TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editPrecoAlcool = findViewById(R.id.editPrecoAlcool);
        editPrecoGasolina = findViewById(R.id.editPrecoGasolina);
        textResultado = findViewById(R.id.textResultado);
    }

    public boolean validaCampos(String pAlcool, String pGasolina){

        boolean res = true;

        if (pAlcool == null || pAlcool.equals("")){
            res = false;
        }else if (pGasolina == null || pGasolina.equals("")){
            res = false;
        }

        return res;
    }


    public void calcula(View view){

        String alcool = editPrecoAlcool.getText().toString();
        String gasolina = editPrecoGasolina.getText().toString();

        boolean camposValidados = this.validaCampos(alcool, gasolina);

        if (camposValidados){
            this.calculaMelhorPreco(alcool, gasolina);
        }else  {
            textResultado.setText("Preencha todos os preços antes de calcular!");
        }

    }


    public void calculaMelhorPreco(String alcool, String gasolina){

        Double  pAlcool = Double.parseDouble(alcool);
        Double pGasolina = Double.parseDouble(gasolina);
        Double resultado = pAlcool / pGasolina;

        if(resultado >= 0.7){
            textResultado.setText("Melhor utilizar Gasolina");
        }else{
            textResultado.setText("Melhor utilizar Álcool");
        }

    }
}
